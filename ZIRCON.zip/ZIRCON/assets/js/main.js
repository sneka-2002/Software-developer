
  window.addEventListener('scroll', function() {
    var box = document.querySelector('.head-section');
    var scrollPosition = window.scrollY;

    if (scrollPosition >= 100) { // Change 200 to your desired scroll position
      box.classList.add('scrolled');
    } else {
      box.classList.remove('scrolled');
    }
  });

  